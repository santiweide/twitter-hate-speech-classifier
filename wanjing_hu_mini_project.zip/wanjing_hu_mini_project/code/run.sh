# run amphate training
python amphate_train.py
# run inference and eval
python amphate_infer.py

# run roberta train
python roberta.py
# run roberta infer
python roberta_infer.py